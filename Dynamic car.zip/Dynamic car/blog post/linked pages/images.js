var idgeter;

function imgbigger(el){
				/*  
			idgeter = 	el.id;
			let id = document.getElementById(idgeter)
			let bg = document.getElementById("backgroundcreater");
				bg.style.background = "#d5fff4"
				bg.style.display = "block"
				id.style.width = '100vw';
				id.style.position = 'fixed'							
				id.style.zIndex = '6';
				id.style.marginLeft = '-1vw';
				id.style.height = 'auto';
				id.style.border = '0px'
				
			
			let metachanger =	document.querySelector('meta[name= viewport]')
				metachanger.setAttribute('content', 'width=device-width');
				 */
}


				
				function closeimg(el) {
				
			let id = document.getElementById(idgeter)
			let bg = document.getElementById("backgroundcreater");
				bg.style.background = ""
				bg.style.display = ""
				id.style.width = '';
				id.style.position = ''							
				id.style.zIndex = '';
				id.style.marginLeft = '';
				id.style.paddingTop = '';
				id.style.height = '';
				window.history.back();
				let metachanger =	document.querySelector('meta[name= viewport]')
			metachanger.setAttribute('content', 'width=device-width, minimum-scale= 1.0, maximum-scale = 1.0, user-scalable = no');
}


//for image resize whan back button down
function onLoad() {
        document.addEventListener("deviceready", onDeviceReady, false);
    }

function onDeviceReady() {
        // Register the event listener
        document.addEventListener("backbutton", onBackKeyDown, false);
    }
				
function onBackKeyDown() {
     console.log('back button down')
 }
