const search = () => {
deleteChild();

let filter = 	document.getElementById('myinput').value.toUpperCase();

let unsugg = [];

for (let i = 0; i<suggestions.length; i++){

				let sugg = suggestions[i].toUpperCase();
				
				for(let j=0; j<sugg.length; j++){
								if(sugg.indexOf(filter)>-1) {
								
							  unsugg.push(sugg);
							  						   
								console.log(unsugg);					
												break;
												
						  	}
				  }
		 	}
		 	
function creatli () {

      let list = document.getElementById("searchlist");
       
      unsugg.forEach((item) => { 

        let li = document.createElement("li"); 

        li.innerText = item; 

        list.appendChild(li); 

      }); 
 }
 
		 	creatli();
		
}

function deleteChild() { 
    var e = document.getElementById("searchlist");   
        
      var child = e.lastElementChild;  

        while (child) { 
       e.removeChild(child); 

   child = e.lastElementChild; 
    } 
} 

function lang11(event) {
    	
    				let searchfill = event.target.innerHTML;
       
        var target = event.target || event.srcElement;
            document.getElementById("myinput").value = searchfill;
      
       clll();
    }
 
 
 window.addEventListener('mouseup', function (event) {

 var filter = document.getElementById('myinput');

 				var disapear =  document.getElementById('searchlist');
 	
 				if (event.target != disapear && event.target != filter && event.target.parentNode != disapear) {
 								searchlist.style.display = 'none';
 								document.getElementById('searchd').style.display = 'none';
 							 							
 				}
 });
 

 window.addEventListener('mouseup', function (event) {
 var filter = document.getElementById('myinput');
 				var disapear =  document.getElementById('searchlist');
 				if (event.target == disapear || event.target == filter || event.target.parentNode == disapear) {
 								searchlist.style.display = 'block';
 				}
 });
 
 
 
document.getElementById('searchlist').onclick = function () {
  lang11(event);
  searchlist.style.display = 'none';
 
}


const clll = () => {
  let filter = document.getElementById("myinput").value.toUpperCase();
  for (let i = 0; i<suggestions.length; i++) {
			if (filter == suggestions [i]){
			window.open(links[i]);
										
							}
				}			
}


const searchclike = () =>{
			
			document.getElementById('searchd').style.display = 'block';
			
document.getElementById('myinput').focus();

let searchlist1 = document.getElementById('searchlist')

  searchlist1.style.display = 'block';
			
}

const clearsearchbar = () => {
			document.getElementById('searchd').style.display = 'block';
				document.getElementById('myinput').value = "";
				
}


const closesearch = () => {
				document.getElementById('searchd').style.display = 'none';
}

const manushow = () =>{
				document.querySelector('.manu ul ul').style.display = 'block';
				
}
const manuunhide = () =>{
				document.querySelector('.manu ul ul').style.left = '0';
										
}


const manuhide = () => {
let cheker =document.querySelector('.manu ul ul').style.display;
				if (cheker == 'block') {
				
								manubarhider();
				}
				
}


window.addEventListener('mouseup', function (event) {

	var manuimgg = document.getElementById("manuimg");

 var manuu = document.querySelector('.manu ul ul');

 				var disapear =  document.getElementById('manu1');
 	
 		  		if (event.target == disapear || event.target == manuu || event.target == manuimgg) {
 				
 				document.querySelector('*')	.style.position = 'absolut';
 				document.querySelector('*')	.style.left = '75vw';
 			document.querySelector('.manu ul ul').style.display = 'block'		; 			
								 											 								
 							document.querySelector('.manu ul ul').style.left = '0';
 							
 							
 				}
 				else {
 				
 				document.querySelector('.manu ul ul').style.left = '-75vw';
 				document.querySelector('.manu ul ul').style.display = 'none'		;
 				
 					
 	 				} 
 });

window.addEventListener('mouseup', function (event) {
				let ulli = document.querySelector('#searchlist li')
				let ul = document.getElementById('searchlist').innerHTML
				if(event.target == ul && event.target != ulli) {
								document.getElementById('myinput').value = '';
				}
})

 var midelchanger = document.getElementsByClassName("midel");

for (var i = 0; i < midelchanger.length; i++) {
  midelchanger[i].innerHTML = "  :-  ";
  }


