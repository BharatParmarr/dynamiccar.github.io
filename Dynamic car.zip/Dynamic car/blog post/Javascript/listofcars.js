let suggestions = [
"Land Rover Range Rover Evoque 2.0",
				"ROLLS-ROYCE CULLINAN",
				"ROLLS-ROYCE DOWN",
				"ROLLS-ROYCE GHOST",
				"ROLLS-ROYCE PHANTOM",
				"ROLLS-ROYCE WRAITH",
				"ghxst"
]

let links = ["a","https://www.google.com/search?q=touppercase+java&oq=toupp&aqs=chrome.1.69i57j0i433i512j0i512l3.3683j0j7&client=ms-android-xiaomi-rev1&sourceid=chrome-mobile&ie=UTF-8",
				"/storage/emulated/0/Android/data/com.teejay.trebedit/files/TrebEdit user files/prectic (larning)/search bar/search try 2/down.html"
]
