var suggestions = [
				"ROLLS-ROYCE CULLINAN",
				"ROLLS-ROYCE DOWN",
				"ROLLS-ROYCE GHOST",
				"ROLLS-ROYCE PHANTOM",
				"ROLLS-ROYCE WRAITH"
]


let link1 = "https:/";
link1 += "/www.google.com/search?q=touppercase+java&oq=toupp&aqs=chrome.1.69i57j0i433i512j0i512l3.3683j0j7&client=ms-android-xiaomi-rev1&sourceid=chrome-mobile&ie=UTF-8";

var links = [link1,
"https:/www.google.com/search?q=touppercase+java&oq=toupp&aqs=chrome.1.69i57j0i433i512j0i512l3.3683j0j7&client=ms-android-xiaomi-rev1&sourceid=chrome-mobile&ie=UTF-8",
				"/storage/emulated/0/Android/data/com.teejay.trebedit/files/TrebEdit user files/prectic (larning)/search bar/search try 2/down.html", "/storage/emulated/0/Android/data/com.teejay.trebedit/files/TrebEdit%20user%20files/Dynamic%20car/RollsRoycePhantom.html"]

let aaaaa = "abc/";
aaaaa += "/bacd";
